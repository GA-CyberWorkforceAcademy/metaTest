<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");

$chatlog = fopen("../../log.html", "r") or die("An error has occured while loading chat log");
$content = fread($chatlog, filesize("../../log.html"));
fclose($chatlog);
print $content;
?>

